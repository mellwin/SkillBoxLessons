﻿namespace TryException
{
    public interface IUseEx
    {
        string DefaultMessage { get; }
    }
}

﻿namespace WpfApp1
{
    public enum MenuActions
    {
        AddCustumer,
        ChangeAccount,
        DeleteCustumer,
        DeleteAccount
    }

    public enum MenuObjects
    {
        Custumer,
        Account,
        Transaction
    }
}
